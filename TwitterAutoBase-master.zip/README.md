# Twitter Auto Base

![system schema](https://i.ibb.co/WxrpzrV/carbon.png)

Twitter Auto Base it’s a console based script created for bot that works like others auto base account

# Features

  - Check DM once 1 minutes
  - Image support
  - Send DM after menfess tweeted

# Installation

Twitter Auto Base requires [PHP](https://www.php.net/) to run.
Edit file config.php before you run this script
```sh
$ git clone https://github.com/nthanfp/TwitterAutoBase
$ cd TwitterAutoBase
$ php AutoBase.php
```

