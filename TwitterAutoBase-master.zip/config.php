<?php
//Account Settings//
define('CONSUMER_KEY', '9tR7O1dnm8uhmxgFUF5SoEa4J'); //Your CONSUMER KEY
define('CONSUMER_SECRET', 'TiOg13GnUnJKTM7D9RHivhFHqVP6NRQjZfgB092bwf1cAqsWwO'); //Your CUSTOMER SECRET
define('access_token', '451516864-yeLVFjwFOzwkjNk9yWaArTDHjjKw9rbi7rxrAPzy'); //Your account ACCESS TOKEN
define('access_token_secret', 'PP6P9e5g9Ta4XVyf2d1kb6l03beUq7o0ttP6hyXh3UIwU'); //Your account ACCESS TOKEN SECRET
//BOT Settings//
define('KEYWORD', 'petet'); //Keyword or trigger bot
define('SPEED', 60);